// our JSON data

const employeeJSON = {
    employees: [
      {
        firstname: "John",
        lastname: "Smith",
        start_date: "11/07/2008",
        employed: false,
      },
      {
        firstname: "Mike",
        lastname: "Wazowski",
        start_date: "08/02/2002",
        employed: true,
      },
      {
        firstname: "Lightning",
        lastname: "McQueen",
        start_date: "28/07/2006",
        employed: true,
      },
      {
        firstname: "Oscar",
        lastname: "Wild",
        start_date: "16/10/1954",
        employed: false,
      },
      {
        firstname: "James",
        lastname: "Sullivan",
        start_date: "08/02/2002",
        employed: true,
      },
      {
        firstname: "Briar",
        lastname: "Rose",
        start_date: "07/29/1959",
        employed: true,
      },
      {
        firstname: "Peter",
        lastname: "Pan",
        start_date: "27/07/1953",
        employed: true,
      },
      {
        firstname: "Jack",
        lastname: "Sparrow",
        start_date: "24/05/2007",
        employed: true,
      },
      {
        firstname: "Christopher",
        lastname: "Robin",
        start_date: "21/08/1921",
        employed: false,
      },
    ],
  };
  